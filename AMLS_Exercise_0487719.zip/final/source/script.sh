#! /bin/bash

python3 prepare.py

python3 main.py